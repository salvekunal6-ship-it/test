const isIOS = /iPhone|iPad|iPod/i.test(navigator.userAgent);
const isAndroid = /Android/i.test(navigator.userAgent);

window.addEventListener('DOMContentLoaded', (event) => {
    const googlePayElement = document.querySelector("[pay-type='gpay']");
    const phonePeElement = document.querySelector("[pay-type='phonepe']");
    const paytmElement = document.querySelector("[pay-type='paytm']");

    // Show or hide elements based on the device type
    if (isAndroid) {
        // Show Google Pay for Android, hide PhonePe and Paytm
        googlePayElement.style.display = "block";
        phonePeElement.style.display = "block";
        paytmElement.style.display = "block";
    } else if (isIOS) {
        // Show PhonePe and Paytm for iOS, hide Google Pay
        googlePayElement.style.display = "none";
        phonePeElement.style.display = "block";
        paytmElement.style.display = "none";
    } else {
        // Hide all for unsupported devices (if any)
        googlePayElement.style.display = "none";
        phonePeElement.style.display = "none";
        paytmElement.style.display = "none";
    }
});
